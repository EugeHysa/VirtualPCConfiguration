function setCompCookie(name, value)
{
    document.cookie = name + "=" + value;
    alert(document.cookie);
}