package Exceptions;

/**
 *
 * @author Utente
 */
public class InvalidListOfArgumentsException extends Exception {

    /**
     *
     */
    public InvalidListOfArgumentsException() {
        
        super("One or more arguments are missing.");
    }

    /**
     *
     * @return
     */
    public String toString () {
        return getMessage();
    }

}
